Examples
========

Here are some examples of using `libact`:

.. toctree::
  :maxdepth: 1

  plot.rst
  label_digits.rst
  multilabel_active_learning.rst
