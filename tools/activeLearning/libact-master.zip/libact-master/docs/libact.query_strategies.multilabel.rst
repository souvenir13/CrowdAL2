libact.query_strategies.multilabel package
==========================================

Submodules
----------

libact.query_strategies.multilabel.adaptive_active_learning module
-------------------------------------------------------------------------------

.. automodule:: libact.query_strategies.multilabel.adaptive_active_learning
    :members:
    :undoc-members:
    :show-inheritance:


libact.query_strategies.multilabel.binary_minimization module
-------------------------------------------------------------------------------

.. automodule:: libact.query_strategies.multilabel.binary_minimization
    :members:
    :undoc-members:
    :show-inheritance:

libact.query_strategies.multilabel.maximum_margin_reduction module
-------------------------------------------------------------------------------

.. automodule:: libact.query_strategies.multilabel.maximum_margin_reduction
    :members:
    :undoc-members:
    :show-inheritance:

libact.query_strategies.multilabel.multilabel_with_auxiliary_learner module
-------------------------------------------------------------------------------

.. automodule:: libact.query_strategies.multilabel.multilabel_with_auxiliary_learner
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: libact.query_strategies.multilabel
    :members:
    :undoc-members:
    :show-inheritance:
