libact.labelers package
=======================

Submodules
----------

libact.labelers.ideal_labeler module
------------------------------------

.. automodule:: libact.labelers.ideal_labeler
    :members:
    :undoc-members:
    :show-inheritance:

libact.labelers.interactive_labeler module
------------------------------------------

.. automodule:: libact.labelers.interactive_labeler
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: libact.labelers
    :members:
    :undoc-members:
    :show-inheritance:
