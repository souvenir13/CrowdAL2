"""
Concrete labeler classes.
"""

from .ideal_labeler import IdealLabeler
from .interactive_labeler import InteractiveLabeler
